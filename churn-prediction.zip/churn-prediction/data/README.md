# Data

This project uses the **Telco Customer Churn** dataset (IBM sample data, 7,043 customers, 21 columns), available on Kaggle:
https://www.kaggle.com/datasets/blastchar/telco-customer-churn

Download `WA_Fn-UseC_-Telco-Customer-Churn.csv` and place it in the **project root** (next to the notebook), since the notebook loads it with a relative path. Alternatively, put it in this folder and change the path in the notebook to `data/WA_Fn-UseC_-Telco-Customer-Churn.csv`.

The CSV is git-ignored so the dataset is not re-distributed in this repository.
